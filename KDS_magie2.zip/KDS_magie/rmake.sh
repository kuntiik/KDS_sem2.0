
#!/bin/bash
g++ server.cpp -lz -o server -lssl -lcrypto
