#!/bin/bash
g++ client.cpp -lz -o client -lssl -lcrypto
